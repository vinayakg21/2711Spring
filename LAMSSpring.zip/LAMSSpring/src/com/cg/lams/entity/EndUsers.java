package com.cg.lams.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="LAPSUsers")
public class EndUsers {
	
	@Id
	@Column(name="LOGIN_ID")
	@NotEmpty(message="Please Enter Username")
	String login_id;
	
	@Column(name="PASSWORD")
	@NotEmpty(message="Please Enter Password")
	String password;
	
	@Column(name="ROLE")
	String role;
	
	public EndUsers() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public EndUsers(String login_id, String password, String role) {
		super();
		this.login_id = login_id;
		this.password = password;
		this.role = role;
	}
	
	
	public String getLogin_id() {
		return login_id;
	}
	public void setLogin_id(String login_id) {
		this.login_id = login_id;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	@Override
	public String toString() {
		return "EndUser [login_id=" + login_id + ", password=" + password
				+ ", role=" + role + "]";
	}
	
}
