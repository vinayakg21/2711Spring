package com.cg.lams.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="LAPSLoanProgramsOffered")
public class LoanProgramsOffered {
	
	@Id
	@Column(name="PROGRAMNAME")
	@NotEmpty(message="Please Enter Program Name")
	String ProgramName;
	
	@Column(name="DESCRIPTION")
	@NotEmpty(message="Please Enter the Description")
	String description; 
	
	@Column(name="TYPE")
	@NotEmpty(message="Please Enter the Type")
	String type;
	
	@Column(name="DURATIONINYEARS")
	@NotNull(message="Please Enter the Duration")
	int durationinyears;
	
	@Column(name="MINLOANAMOUNT")
	@NotNull(message="Please Enter the Minimum Loan Amount")
	double minloanamount;
	
	@Column(name="MAXLOANAMOUNT")
	@NotNull(message="Please Enter the Maximum Loan Amount")
	double maxloanamount;
	
	@Column(name="RATEOFINTEREST")
	@NotNull(message="Please Enter the Rate of Interest")
	double rateofinterest;
	
	@Column(name="PROOFS_REQUIRED")
	@NotEmpty(message="Please Enter the PROOFS_REQUIRED")
	String proofs_required;
	
	public String getProgramName() {
		return ProgramName;
	}
	public void setProgramName(String programName) {
		ProgramName = programName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public int getDurationinyears() {
		return durationinyears;
	}
	public void setDurationinyears(int durationinyears) {
		this.durationinyears = durationinyears;
	}
	public double getMinloanamount() {
		return minloanamount;
	}
	public void setMinloanamount(double minloanamount) {
		this.minloanamount = minloanamount;
	}
	public double getMaxloanamount() {
		return maxloanamount;
	}
	public void setMaxloanamount(double maxloanamount) {
		this.maxloanamount = maxloanamount;
	}
	public double getRateofinterest() {
		return rateofinterest;
	}
	public void setRateofinterest(double rateofinterest) {
		this.rateofinterest = rateofinterest;
	}
	public String getProofs_required() {
		return proofs_required;
	}
	public void setProofs_required(String proofs_required) {
		this.proofs_required = proofs_required;
	}
	public LoanProgramsOffered(String programName, String description,
			String type, int durationinyears, double minloanamount,
			double maxloanamount, double rateofinterest, String proofs_required) {
		super();
		ProgramName = programName;
		this.description = description;
		this.type = type;
		this.durationinyears = durationinyears;
		this.minloanamount = minloanamount;
		this.maxloanamount = maxloanamount;
		this.rateofinterest = rateofinterest;
		this.proofs_required = proofs_required;
	}
	@Override
	public String toString() {
		return "\nProgramName=" + ProgramName
				+ ", \ndescription=" + description + ", \ntype=" + type
				+ ", \ndurationinyears=" + durationinyears + ", \nminloanamount="
				+ minloanamount + ", \nmaxloanamount=" + maxloanamount
				+ ", \nrateofinterest=" + rateofinterest + ", \nproofs_required="
				+ proofs_required +"\n";
	}
	public LoanProgramsOffered() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
