package com.cg.lams.entity;

import java.sql.Date;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="lapscustomerdetails")
public class CustomerDetails {
	
	@Id
	@Column(name="APPLICATION_ID")
	int applicationId; 
	
	@Column(name="APPLICANT_NAME")
	@NotEmpty(message="Please Enter the Name")
	String applicantName;
	
	@Column(name="DATE_OF_BIRTH")
	@NotNull(message="Please Enter the Birth Date")
	Date dateOfBirth;
	
	@Column(name="MARTIAL_STATUS")
	@NotEmpty(message="Please Enter the Maritial Status")
	String maritalStatus;
	
	@Column(name="PHONE_NUMBER")
	@NotNull(message="Please Enter the Phone Number")
	int phoneNumber;
	
	@Column(name="MOBILE_NUMBER")
	@NotNull(message="Please Enter the Mobile Number")
	int mobileNumber;
	
	@Column(name="COUNTOFDEPENDENTS")
	@NotNull(message="Please Enter the Count of Dependents")
	int countOfDependents; 
	
	@Column(name="EMAIL_ID")
	@NotEmpty(message="Please Enter the Email ID")
	String emailId;
	
	public CustomerDetails() {
		// TODO Auto-generated constructor stub
	}

	public CustomerDetails(int applicationId, String applicantName,
			Date dateOfBirth, String maritalStatus, int phoneNumber,
			int mobileNumber, int countOfDependents, String emailId) {
		super();
		this.applicationId = applicationId;
		this.applicantName = applicantName;
		this.dateOfBirth = dateOfBirth;
		this.maritalStatus = maritalStatus;
		this.phoneNumber = phoneNumber;
		this.mobileNumber = mobileNumber;
		this.countOfDependents = countOfDependents;
		this.emailId = emailId;
	}

	public int getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(int applicationId) {
		this.applicationId = applicationId;
	}

	public String getApplicantName() {
		return applicantName;
	}

	public void setApplicantName(String applicantName) {
		this.applicantName = applicantName;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public int getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(int phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public int getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(int mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public int getCountOfDependents() {
		return countOfDependents;
	}

	public void setCountOfDependents(int countOfDependents) {
		this.countOfDependents = countOfDependents;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	@Override
	public String toString() {
		return "CustomerDetails [applicationId=" + applicationId
				+ ", applicantName=" + applicantName + ", dateOfBirth="
				+ dateOfBirth + ", maritalStatus=" + maritalStatus
				+ ", phoneNumber=" + phoneNumber + ", mobileNumber="
				+ mobileNumber + ", countOfDependents=" + countOfDependents
				+ ", emailId=" + emailId + "]";
	}
	
	
	
}
