package com.cg.lams.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.lams.entity.ApprovedLoans;
import com.cg.lams.entity.LoanApplication;
import com.cg.lams.entity.LoanProgramsOffered;

@Repository
public class AdminDaoImpl implements AdminDao {

	@PersistenceContext
	EntityManager em;
	
	public AdminDaoImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void addLoanProgram(LoanProgramsOffered loanProgram) {
		// TODO Auto-generated method stub
		em.persist(loanProgram);
	}

	@Override
	public void updateLoanProgram(LoanProgramsOffered loanProgram) {
		// TODO Auto-generated method stub
		em.merge(loanProgram);
	}

	@Override
	public void deleteLoanProgram(String programName) {
		// TODO Auto-generated method stub
		LoanProgramsOffered lpo = em.find(LoanProgramsOffered.class, programName);
		em.remove(lpo);
	}

	@Override
	public List<ApprovedLoans> viewApprovedLoanProgram() {
		// TODO Auto-generated method stub
		String jpql = "Select loan from ApprovedLoans loan";
		TypedQuery<ApprovedLoans> query = em.createQuery(jpql, ApprovedLoans.class);
		return query.getResultList();
	}

	@Override
	public List<LoanApplication> viewAppliedLoanProgram() {
		// TODO Auto-generated method stub
		String str=
				"select loan from LoanApplication loan where loan.status=:status";
				TypedQuery<LoanApplication> query= em.createQuery(str, LoanApplication.class);
				query.setParameter("status", "applied");
				List<LoanApplication> list=query.getResultList();
				return list;
	}

	@Override
	public List<LoanApplication> viewRejectedLoanProgram() {
		// TODO Auto-generated method stub
		String str=
				"select loan from LoanApplication loan where loan.status=:status";
				TypedQuery<LoanApplication> query= em.createQuery(str, LoanApplication.class);
				query.setParameter("status", "rejected");
				List<LoanApplication> list=query.getResultList();
				return list;
	}

}
