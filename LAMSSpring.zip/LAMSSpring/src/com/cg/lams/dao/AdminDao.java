package com.cg.lams.dao;

import java.util.List;

import com.cg.lams.entity.ApprovedLoans;
import com.cg.lams.entity.LoanApplication;
import com.cg.lams.entity.LoanProgramsOffered;

public interface AdminDao {

	void addLoanProgram(LoanProgramsOffered loanProgram);

	void updateLoanProgram(LoanProgramsOffered loanProgram);

	void deleteLoanProgram(String programName);

	List<ApprovedLoans> viewApprovedLoanProgram();

	List<LoanApplication> viewAppliedLoanProgram();

	List<LoanApplication> viewRejectedLoanProgram();

}
