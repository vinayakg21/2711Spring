package com.cg.lams.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.lams.entity.EndUsers;
import com.cg.lams.entity.LoanProgramsOffered;
import com.cg.lams.exception.LAMSException;

@Repository
public class CommonDaoImpl implements CommonDao {

	@PersistenceContext
	EntityManager em;
	
	public CommonDaoImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public EndUsers login(EndUsers user) throws LAMSException {
		// TODO Auto-generated method stub
		try {
		String str="select user from EndUsers user where user.login_id=:userId and user.password=:password and user.role=:role";
				TypedQuery<EndUsers> query= em.createQuery(str, EndUsers.class);
				query.setParameter("userId", user.getLogin_id());
				query.setParameter("password", user.getPassword());
				query.setParameter("role", user.getRole());
				
				EndUsers userResult=query.getSingleResult();
				return userResult;
		}
		catch(NoResultException e){
			throw new NullPointerException("Invalid User");
		}
	}

	@Override
	public List<LoanProgramsOffered> viewLoanProgramOffered() {
		// TODO Auto-generated method stub
		String jpql = "Select loanprog from LoanProgramsOffered loanprog";
		TypedQuery<LoanProgramsOffered> query = em.createQuery(jpql, LoanProgramsOffered.class);
		return query.getResultList();
	}

	@Override
	public LoanProgramsOffered getAllLoanPrograms(String programName) {
		// TODO Auto-generated method stub
		return em.find(LoanProgramsOffered.class, programName);
	}

}
