package com.cg.lams.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.lams.dao.AdminDao;
import com.cg.lams.entity.ApprovedLoans;
import com.cg.lams.entity.LoanApplication;
import com.cg.lams.entity.LoanProgramsOffered;

@Service
@Transactional
public class AdminServiceImpl implements AdminService {

	@Autowired
	AdminDao adao;
	
	public AdminServiceImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void addLoanProgram(LoanProgramsOffered loanProgram) {
		// TODO Auto-generated method stub
		adao.addLoanProgram(loanProgram);
	}

	@Override
	public void updateLoanProgram(LoanProgramsOffered loanProgram) {
		// TODO Auto-generated method stub
		adao.updateLoanProgram(loanProgram);
	}

	@Override
	public void deleteLoanProgram(String programName) {
		// TODO Auto-generated method stub
		adao.deleteLoanProgram(programName);
	}

	@Override
	public List<ApprovedLoans> viewApprovedLoanProgram() {
		// TODO Auto-generated method stub
		return adao.viewApprovedLoanProgram();
	}

	@Override
	public List<LoanApplication> viewAppliedLoanProgram() {
		// TODO Auto-generated method stub
		return adao.viewAppliedLoanProgram();
	}

	@Override
	public List<LoanApplication> viewRejectedLoanProgram() {
		// TODO Auto-generated method stub
		return adao.viewRejectedLoanProgram();
	}

}
